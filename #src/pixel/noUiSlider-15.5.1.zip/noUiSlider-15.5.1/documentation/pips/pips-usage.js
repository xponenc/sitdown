slider.noUiSlider.pips(/* options */);

// Find the current set of pips.
slider.querySelector('.noUi-pips');
